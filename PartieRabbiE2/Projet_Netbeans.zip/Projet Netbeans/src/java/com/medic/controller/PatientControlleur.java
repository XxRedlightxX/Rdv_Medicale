/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.medic.controller;
import com.medic.entities.Patient;
import com.medic.service.PatientService;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author amirh
 */
public class PatientControlleur extends HttpServlet {
 List<Patient> listePatients;
 Patient patient =null; 
 PatientService patientService = new PatientService();

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        
        String nom = request.getParameter("nom");
        if (nom != null && !nom.equals("")){
        
        request.setAttribute("listePatients",  patientService.chercherPatientParNom(nom));
         request.getRequestDispatcher("Medecin.jsp").forward(request, response);
        } else {
            request.getRequestDispatcher("Medecin.jsp").forward(request, response);}
        
        
         
        }
        
    }
 

